<template>
  <div class="grey darken-1 empty-layout">
    <router-view />
  </div>
</template>
